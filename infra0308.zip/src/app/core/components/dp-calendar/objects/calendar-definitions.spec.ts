import { CalendarDefinitions } from './calendar-definitions';

describe('CalendarDefinitions', () => {
  it('should create an instance', () => {
    expect(new CalendarDefinitions()).toBeTruthy();
  });
});
