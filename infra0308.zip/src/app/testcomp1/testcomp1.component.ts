import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testcomp1',
  templateUrl: './testcomp1.component.html',
  styleUrls: ['./testcomp1.component.scss']
})
export class Testcomp1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
